$(document).on('ready', function() {
    "use strict";
    
});

$('.slider-carsoule').owlCarousel({
    loop: true,
    margin: 10,
    autoplay: true,
    nav: true,
    navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 1
        },
        1000: {
            items: 1
        }
    }
})

$('.partner-logo-carousel').owlCarousel({
    loop: true,
    margin: 10,
    autoplay: true,
    dot: true,
    nav: false,
    navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
    responsive: {
        0: {
            items: 2
        },
        600: {
            items: 4
        },
        1000: {
            items: 4
        }
    }
})
 

$('.post-carousel').owlCarousel({
    loop: true,
    margin: 10,
    autoplay: true,
    dot: true,
    nav: false,
    navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 1
        },
        1000: {
            items: 1
        }
    }
})

$('.carousel-1').owlCarousel({
    loop: true,
    margin:10,
    autoplay: true,
    dot: true,
    nav: true,
    navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 2
        },
        1000: {
            items: 2
        }
    }
})



