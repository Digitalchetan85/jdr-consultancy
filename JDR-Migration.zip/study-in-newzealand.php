<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>JDR Migration</title>
    <link rel="icon" href="assets/images/logoicon.jpg" type="image/jpg">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- FontAwesome 4.0 CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
    <!-- Google Font CSS -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700%7cPT+Serif:400,400i,700,700i" rel="stylesheet">
    <!-- Style CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/css/main.css">
</head>

<body>
    <div id="navbar" class="sticky-top">
        <div class="topbar bg-primary">
            <!-- topbar -->
            <div class="container">
                <div class="row">
                    <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12 col-12 d-none d-sm-none d-lg-block d-xl-block">
                        <p class="welcome-text">Welcome to JDR Migration</p>
                    </div>
                    <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12 col-12">
                        <div class="header-block">
                            <span class="header-link d-none d-xl-block"><a data-toggle="modal" data-target="#searchModal" class="anchor-link text-white text-decoration-none">Talk to Our Expert</a></span>
                            <span class="header-link">info@jdrmigration.com</span>
                            <span class="header-link"><a href="#" target="_blank"><i class="fa fa-facebook m-1"></i></a></span>
                            <span class="header-link"><a href="#" target="_blank"><i class="fa fa-linkedin m-1"></i></a></span>
                            <span class="header-link"><a href="#"><i class="fa fa-instagram m-1"></i></a></span>
                            <span class="header-link"><a href="#"><i class="fa fa-youtube m-1"></i></a></span>
                            <span class="header-link"><a href="#"><i class="fa fa-twitter m-1"></i></a></span>




                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="">

            <!-- <div class="row justify-content-center">
                <div class="col-xl-9 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div id="navigation-regular" class="">
                        navigation
                      <ul class="">
                            <li><a href="#">Home</a></li>
                            <li><a href="about.php">About Us</a></li>
                            <li><a href="#">Services</a>
                                <ul>
                                    <li><a href="free-counselling.php">Counselling </a></li>
                                    <li><a href="#">Visa Filling </a></li>
                                    <li><a href="#">Flight Bookings </a></li>
                                </ul>
                            </li>
                            <li><a href="study_abroad.html">Study Abroad</a>
                                <ul>
                                    <li><a href="study-in-usa.php">STUDY IN USA</a></li>
                                    <li><a href="#">STUDY IN UK</a></li>
                                    <li><a href="#">STUDY IN NEW ZEALAND</a></li>
                                    <li><a href="#">STUDY IN AUSTRALIA </a></li>
                                </ul>
                            </li>
                            <li><a href="coaching.php">Coaching</a></li>
                            <li><a href="certifications.php">Certifications</a></li>
                            <li><a href="contact.php">Contact Us</a></li>
                        </ul>
                    </div>
                </div>
            </div> -->
            <nav class="navbar-expand-lg navbar-light bg-white">
                <div class="container-fluid">
                    <button class="navbar-toggler pb-2 ms-auto me-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
                        <a class="navbar-brand ps-5" href="/jdr-consultancy">
                            <img src="assets/images/logo.jpg" alt="">
                        </a>
                        <ul class="navbar-nav ms-auto me-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <a class="nav-link " aria-current="page" href="/">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link " href="about.php">About Us</a>
                            </li>
                            <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
                                <ul class="navbar-nav">
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle " href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            Services
                                        </a>
                                        <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
                                            <li><a class="dropdown-item" href="free-counselling.php">Counselling</a></li>
                                            <li><a class="dropdown-item" href="visa-filling.php">Visa Filling</a></li>
                                            <li><a class="dropdown-item" href="flight-booking.php">Flight Bookings</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                            <!-- <li><a href="#">Services</a>
                                <ul>
                                    <li><a href="free-counselling.php">Counselling </a></li>
                                    <li><a href="#">Visa Filling </a></li>
                                    <li><a href="#">Flight Bookings </a></li>
                                </ul>
                            </li> -->
                            <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
                                <ul class="navbar-nav">
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            Study In Abroad
                                        </a>
                                        <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
                                            <li><a class="dropdown-item" href="study-in-australia.php">Study In Australia</a></li>
                                            <li><a class="dropdown-item" href="study-in-canada.php">Study In Canada</a></li>
                                            <li><a class="dropdown-item" href="study-in-dubai.php">Study In Dubai</a></li>
                                            <li><a class="dropdown-item" href="study-in-malta.php">Study In Malta</a></li>
                                            <li><a class="dropdown-item" href="study-in-newzealand.php">Study In New Zealand</a></li>
                                            <li><a class="dropdown-item" href="study-in-singapore.php">Study IN Singapore</a></li>
                                            <li><a class="dropdown-item" href="study-in-uk.php">Study IN UK</a></li>
                                            <li><a class="dropdown-item" href="study-in-usa.php">Study IN USA</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>

                            <!-- <li><a href="study_abroad.html">Study Abroad</a>
                            <ul>
                                <li><a href="study-in-usa.php">STUDY IN USA</a></li>
                                <li><a href="#">STUDY IN UK</a></li>
                                <li><a href="#">STUDY IN NEW ZEALAND</a></li>
                                <li><a href="#">STUDY IN AUSTRALIA </a></li>
                            </ul>
                        </li> -->
                            <li class="nav-item">
                                <a class="nav-link" href="coaching.php">Coaching</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="certifications.php">Certifications</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="contact.php">Contact US</a>
                            </li>
                        </ul>

                    </div>
                </div>
            </nav>

        </div>

    </div>

    <div>
        <!-- /.header classic -->
        <div class="page3">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-center">
                        <h1 class="page-title">Study in New Zealand</h1>
                        <p class="page-description">The New Zealand is a country that needs no introduction.<br> If you desire to achieve your goals, the world is your oyster. </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="page-breadcrumb">
            <!-- page breadcrumb -->
            <div class="container">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="/jdr-consultancy">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Study in New Zealand</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.page breadcrumb -->
        <div class="content">
            <div class="container">
                <div class="row">
                    <div class="col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12">
                        <div class="content-area">
                            <h2>New Zealand Visitor Visa </h2>
                            <p>New Zealand is one of the world's most beautiful nations, thanks to its abundance of natural beauty. It is a genuinely one-of-a-kind travel destination when you combine its natural splendor with a contemporary way of life and easy access to cutting-edge technology. The fact that almost 3 million people visit it each year is proof of this.</p>
                            <p>To enter New Zealand without any hassle, travelers must ensure that they have both a valid passport and the appropriate visa before leaving their home country. </p>
                            <p>In all, New Zealand provides more than 80 different types of visas to visitors. There are certain criteria and conditions for each kind of visa. </p>
                            <p>New Zealand's Visitor Visa enables you to stay in the country for no more than nine months at a time.</p>
                            <!-- <img src="images/post-img-3.jpg" alt="" class="img-fluid mb30"> -->
                            <h2>Study in New Zealand for Indian students</h2>
                            <p>To study in New Zealand, you must first get a student visa from the New Zealand government, which is available to all Indian students. The type of study you want to undertake and the length of your stay in New Zealand will determine the type pf visa you require.</p>
                            <p>Applicants for New Zealand's Fee Paying student visa must submit the necessary paperwork.</p>
                            <h4 class="">New Zealand study visa applications typically require the following:</h4>

                            <ul class="listnone check-circle">
                                <li>A valid passport, which must remain valid for at least three months following your visit to New Zealand.</li>
                                <li>A letter of acceptance from a New Zealand academic institution, which indicates the minimum course length, total tuition charge, and whether the tuition fee is in domestic or international currencies. The course has to be approved by the New Zealand Qualifications Authority </li>
                                <li>An offer of placement from an institution that has been recognized by the New Zealand Qualifications Authority</li>
                                <li>Your English Proficiency test results</li>
                                <li>For those under the age of 18, a written promise from an institution or person that adequate housing is available in New Zealand.</li>
                                <li>A plane ticket back to your own country, or proof that you have the money to purchase one.</li>

                            </ul>

                        </div>
                        <div class="py-3 py-md-5">
                            <div class="content-area pt-5 pb-5">
                                <h2 class="text-center">New Zealand Work Visa</h2>
                                <p>New Zealand is a crime-free nation without personal violence or hostility between communities, making it a safe place for families and children. Your knowledge and expertise might be very advantageous to the work being done in New Zealand. New Zealanders have a 'can-do' mentality and like working together to get the job done at work or in business.</p>
                                <!-- <img src="assets/images/post-img-3.jpg" alt="" class="img-fluid mb30"> -->

                                <p>For many years, the high rate of native New Zealander emigration has caused the country to actively encourage skilled immigration.</p>
                                <p>There are many types of New Zealand Work Visa. </p>
                                <h4>Apply for a post-study work visa</h4>
                                <p>The international student market is a significant engine of growth for the New Zealand economy. In 2018, the government of New Zealand made the announcement that it would allow overseas students to remain in the country for up to three years after completing their studies in order to look for jobs.
                                    Candidates have the option of applying for a post-study work visa for a period of 1, 2, or 3 years after a student has completed his or her studies.
                                    .</p>
                                <h4>Skilled Migrant Resident Visa</h4>


                                <p>Skilled Migrant Resident Visas in New Zealand are most often obtained through the Work to Residence Visa route. At least 24 months of employment must be completed throughout its 30 months of validity to be eligible for a permanent visa.</p>

                                <p>Individuals who want to live and work in New Zealand permanently must get a Skilled Migrant Resident Visa.</p>
                            </div>
                            <div class="content-area pt-5 pb-5 ps-2 pe-2 bg-light ">
                                <h2 class="text-center">Why choose JDR Migration?</h2>

                                <p>JDR Migration has been assisting clients with their international migration for many years. A New Zealand visa or work permit application may be complicated if you don't have the right knowledge and support. </p>
                                <p>Our team of immigration specialists can guide you through the process with personalized advice, information, and representation. It is our goal at JDR Migration to assist you with all of the standards that prospective immigrants must meet in order to make their goals a reality.</p>
                                <ul class="listnone check-circle">
                                    <li>Determine whether or not there is a need for someone with your skills in New Zealand.</li>
                                    <li>We are here to provide you with informed guidance: Our experienced professionals will do their best to point you toward the needs that are most important to you.</li>
                                    <li>Make sure you have all of the necessary documentation. It is essential that you thoroughly research the visa category for which you are applying before submitting an application. If all of the needed information is not given, the application process will take much more time.</li>
                                </ul>

                                <p>All of your visa requirements may be met at JDR Migration, from initial profile assessment and documents through application preparation and post-visa support. Contact us as soon as you have any questions or concerns concerning the application process. Let us know if there is anything we can do to assist you.</p>

                                <p>The sooner you start the better. Now is the time to start your visa application!</p>

                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12">

                        <div class="sidebar sticky-top">
                            <div class="widget widget-quote-form bg-light">
                                <h3 class="form-title">Free Immigration Assessment</h3>
                                <p class="form-text">Find out your options for visa by completing a free online assessment.</p>
                                <div class="sidebar-quote-form">
                                    <!-- Text input-->
                                    <div class="form-group">
                                        <label class="control-label sr-only" for="yourname">Your Name</label>
                                        <div class="">
                                            <input id="study-usa-name" name="study-usa-name" type="text" placeholder="Your Name" class="form-control" required="">
                                            <span id="study-usa-name-info" class="text-danger"></span>
                                        </div>
                                    </div>
                                    <!-- Text input-->
                                    <div class="form-group">
                                        <label class="control-label sr-only" for="email">Email</label>
                                        <div class="">
                                            <input id="study-usa-email" name="study-usa-email" type="email" placeholder="Email" class="form-control" required="">
                                            <span id="study-usa-email-info" class="text-danger"></span>
                                        </div>
                                    </div>
                                    <!-- Text input-->
                                    <div class="form-group">
                                        <label class="control-label sr-only" for="mobileno">Mobile No</label>
                                        <div class="">
                                            <input id="study-usa-phone" name="study-usa-phone" type="tel" placeholder="Mobile No" class="form-control" required="">
                                            <span id="study-usa-phone-info" class="text-danger"></span>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="selectvisa" class="sr-only">Select Visa</label>
                                        <select class="form-control" id="study-usa-selectvisa" name="study-usa-selectvisa">
                                            <option value="Select Visa">Select Visa</option>
                                            <option value="Students Visa">Students Visa</option>
                                            <option value="Business Visa">Business Visa</option>
                                            <option value="Family Visa">Family Visa</option>
                                            <option value="Travel Visa">Travel Visa </option>
                                            <option value="Work Visa">Work Visa </option>
                                            <option value="Visitor Visa">Visitor Visa </option>
                                            <option value="Migrate Visa">Migrate Visa </option>
                                            <option value="PR Visa">PR Visa</option>
                                        </select>
                                    </div>
                                    <!-- Textarea -->
                                    <div class="form-group">
                                        <label class="control-label sr-only" for="message">Message</label>
                                        <div class="">
                                            <textarea class="form-control" id="study-usa-message" name="study-usa-message" rows="4" placeholder="Message"></textarea>
                                            <span id="study-usa-info" class="text-danger"></span>
                                        </div>
                                    </div>
                                    <div id="study-usa-mail-status"></div>
                                    <button onClick="sendStudyUsaContact();" class="btn btn-default btn-lg btn-block">Book My Free Assessment</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- <div id="accordion">
                        <div class="card-accordion">
                            <div class="card-accordion-header" id="headingOne">
                                <h5 class="mb-0">
                                    <button class="accordion-btn collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        Documents Required
                                    </button>
                                </h5>
                            </div>
                            <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion" style="">
                                <div class="card-accordion-body">
                                    <p>For application purposes, the following documents are required:</p>
                                    <ul class="listnone check-circle">
                                        <li>Valid Passport</li>
                                        <li>Form V36 and ICA Form 16</li>
                                        <li>Receipt for the S$30 application cost</li>
                                        <li>Student&#39;s Pass issuance fees of S$60 must be paid after the student&#39;s pass has been
                                            accepted and issued.</li>
                                        <li>You require an offer letter from the Singapore university/institute. (Forms are given once
                                            tuition is paid.)</li>
                                        <li>Master’s Degree (without thesis) (MS, MA, Meng)</li>
                                        <li>Two passport-sized photos (if applicable)</li>
                                        <li>Tuition fee + 8400 S$ = Funds to be reflected on the bank statement.</li>
                                        <li>Documentation from the educational institutions that you have attended, such as
                                            transcripts, diplomas, degrees, or certifications.</li>
                                        <li>Test scores which your college considered necessary, like the TOEFL, GRE, or GMAT</li>
                                        <li>How you&#39;ll pay for all of your educational, living, and travel expenses.
                                            Please be aware that further paperwork may be needed. A personal interviewer may ask for
                                            extra documentation to be provided. These might be academic or financial records that verify
                                            one&#39;s standing.</li>
                                    </ul>



                                </div>
                            </div>
                        </div>
                        <div class="card-accordion">
                            <div class="card-accordion-header" id="headingTwo">
                                <h5 class="mb0">
                                    <button class="collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        How Can JDR Migration Be of Assistance to You?
                                    </button>
                                </h5>
                            </div>
                            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion" style="">
                                <div class="card-accordion-body">
                                    <p>At JDR Migration, we provide students with counselling on any of their questions about study
                                        abroad programmes in Singapore. </p>
                                    <h3 class="text-underline">Employment Visa</h3>
                                    <ul class="listnone check-circle">
                                        <li>A work visa, or &quot;work pass&quot; as it is referred to in Singapore, is a work permit that grants a
                                            foreign person the authorization to work in Singapore for a certain amount of time. Work permits
                                            or work passes are necessary for any foreign nationals who want to work in Singapore lawfully. </li>
                                        <li>A job offer from a Singapore-based company is required for those seeking to apply for a
                                            Singapore Work Permit Visa. Applicants for the Employment Pass visa need to demonstrate
                                            that they meet the requirements for salary and skills that are relevant to the Employment Pass
                                            subcategories. </li>
                                        <li>If you're an experienced foreign professional, you may be eligible for a Singapore work visa
                                            called the Personalised Employment Pass (PEP), which does not need you to be sponsored by
                                            a Singapore company. After they arrive in Singapore, those who have applied for a
                                            Personalized Employment Pass visa have six months to find work there.</li>

                                    </ul>
                                    <h3 class="text-underline">Dependent Visa</h3>
                                    <ul class="listnone check-circle">
                                        <li>Those who are granted a work visa in Singapore are allowed to bring their dependents with
                                            them to the country.</li>


                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div> -->

                </div>
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-12">


                    </div>
                </div>
            </div>
        </div>
    </div>





    <!-- {{-- footer --}} -->
    <div id="footer" class="footer">
        <!-- Footer -->
        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-3 col-12">
                    <div class="widget-footer">
                        <h3 class="widget-title">About us</h3>
                        <p>JDR Migration, one of the top Study Abroad & Migration , understand the challenges arising during study migration. Our primary goal is to assist you in scaling through these processes, such as assessment, documentation, and filing.</p>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-6">
                    <div class="widget-footer">
                        <h3 class="widget-title">Study Abroad</h3>
                        <ul class="listnone arrow-footer">

                            <li><a href="study-in-australia.php">Study In Australia</a></li> </a></li>
                            <li><a href="study-in-canada.php">Study In Canada</a></li>
                            <li><a href="study-in-dubai.php">Study In Dubai</a></li>
                            <li><a href="study-in-malta.php">Study In Malta</a></li>
                            <li><a href="study-in-singapore.php">Study In Singapore</a></li>
                            <li><a href="study-in-uk.php">Study In UK</a></li>
                            <li><a href="study-in-usa.php">Study In USA</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-6">
                    <div class="widget-footer">
                        <h3 class="widget-title">Services</h3>
                        <ul class="listnone arrow-footer">
                            <li><a href="free-counselling.php">Counselling </a></li>
                            <li><a href="#">Visa Filling </a></li>
                            <li><a href="#">Flight Bookings </a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-6">
                    <div class="widget-footer">
                        <h3 class="widget-title">Contact Us</h3>
                        <ul class="listnone">
                            <li><a href="#"><i class="fa fa-envelope pr-2"></i> info@jdrmigration.com</a></li>
                            <li><a href="#"><i class="fa fa-envelope pr-2"></i> jdrmigration@gmail.com</a></li>
                            <li><a href="#"><i class="fa fa-phone pr-2"></i> +91 7523999199</a></li>
                            <!-- <li><a href="#"><i class="fa fa-map-marker pr-2"></i>3RD FLOOR, 707, NTI LAYOUT, 10 CROSS, 10TH MAIN, II PHASE, Sahakara Nagar Bengaluru Urban, Karnataka, 560092</a></li> -->
                        </ul>
                        <div class="pt-1"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3886.4983961565113!2d77.58043127668125!3d13.067568784831922!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae194edd460f63%3A0xfeaa6fea6ef67737!2sJDR%20Migration%20Pro!5e0!3m2!1sen!2sin!4v1655705588087!5m2!1sen!2sin" width="100%" height="150" style="border:0;" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>
                        <ul class="listnone mt-2">
                            <a href="#" target="_blank"><i class="fa fa-facebook m-1"></i></a>
                            <a href="#" target="_blank"><i class="fa fa-linkedin m-1"></i></a>
                            <a href="#"><i class="fa fa-instagram m-1"></i></a>
                            <a href="#"><i class="fa fa-youtube m-1"></i></a>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.footer -->
    <div class="tiny-footer">
        <!-- tiny footer -->
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-center">
                    <p><b>Copyright © 2022 JDR Migration. All Rights Reserved. Developed by ShanthasWebz</b></p>
                </div>
            </div>
        </div>
    </div>
    <!-- /.tiny footer -->
    <a href="https://api.whatsapp.com/send?phone=917523999199" class="float" target="_blank">
        <i class="fa fa-whatsapp my-float"></i>
    </a>
    <!-- Search Modal -->
    <div class="searchModal">
        <div class="modal fade" id="searchModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-md" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="enquiry-short-form">
                            <h2>Enter Your Information</h2>
                            <div>
                                <!-- Text input-->
                                <div class="form-group">
                                    <label class="control-label sr-only" for="yourname">Your Name</label>
                                    <div class="">
                                        <input id="name" name="name" type="text" placeholder="Your Name" class="form-control input-md" required="">
                                        <span id="name-info" class="text-danger"></span>
                                    </div>
                                </div>
                                <!-- Text input-->
                                <div class="form-group">
                                    <label class="control-label sr-only" for="email">Email</label>
                                    <div class="">
                                        <input id="email" name="email" type="email" placeholder="Email" class="form-control input-md" required="">
                                        <span id="email-info" class="text-danger"></span>
                                    </div>
                                </div>
                                <!-- Text input-->
                                <div class="form-group">
                                    <label class="control-label sr-only" for="mobile">Mobile No</label>
                                    <div class="">
                                        <input id="phone" name="phone" type="tel" placeholder="Mobile No" class="form-control input-md" required="">
                                        <span id="phone-info" class="text-danger"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="selectvisa" class="sr-only">Select Visa</label>
                                    <select class="form-control" id="selectvisa" name="selectvisa">
                                        <option value="Select Visa">Select Visa</option>
                                        <option value="Students Visa">Students Visa</option>
                                        <option value="Business Visa">Business Visa</option>
                                        <option value="Family Visa">Family Visa</option>
                                        <option value="Travel Visa">Travel Visa </option>
                                        <option value="Work Visa">Work Visa </option>
                                        <option value="Visitor Visa">Visitor Visa </option>
                                        <option value="Migrate Visa">Migrate Visa </option>
                                        <option value="PR Visa">PR Visa</option>
                                    </select>
                                    <span id="selectvisa-info" class="text-danger"></span>
                                </div>
                                <!-- Textarea -->
                                <div class="form-group">
                                    <label class="control-label sr-only" for="message">Message</label>
                                    <div class="">
                                        <textarea class="form-control" id="message" name="message" rows="4" placeholder="Message"></textarea>
                                        <span id="message-info" class="text-center"> </span>
                                    </div>
                                </div>
                                <div id="mail-status"></div>
                                <button class="btn btn-default btn-lg btn-block" onClick="sendContact();">Book My Free Assessment</button>
                            </div>
                            <span class="help-block">We will not spam your email.</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- /.Search Modal -->
    <!-- {{-- footer --}} -->
    <!-- <script src="assets/js/jquery.min.js"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/menumaker.js"></script>
    <script src="assets/js/form.js"></script>
    <script src="assets/js/custom-carousel.js"></script>
    <script src="assets/js/navigation.js"></script>
</body>